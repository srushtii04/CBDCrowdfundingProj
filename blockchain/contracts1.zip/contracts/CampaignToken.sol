// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract CampaignToken is ERC20, ERC20Burnable, Ownable {
    address public minter;

    error NotMinter();
    error ZeroAddress();

    event MinterUpdated(
        address indexed oldMinter,
        address indexed newMinter
    );

    constructor()
        ERC20("Campaign Token", "CFT")
        Ownable(msg.sender)
    {}

    modifier onlyMinter() {
        if (msg.sender != minter) {
            revert NotMinter();
        }
        _;
    }

    function setMinter(address _minter)
        external
        onlyOwner
    {
        if (_minter == address(0)) {
            revert ZeroAddress();
        }

        address oldMinter = minter;

        minter = _minter;

        emit MinterUpdated(
            oldMinter,
            _minter
        );
    }

    function mint(
        address to,
        uint256 amount
    )
        external
        onlyMinter
    {
        _mint(to, amount);
    }
}