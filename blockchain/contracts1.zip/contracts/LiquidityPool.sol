// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/math/Math.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

contract LiquidityPool is ReentrancyGuard {
    using SafeERC20 for IERC20;

    IERC20 public immutable token;

    uint256 public reserveETH;
    uint256 public reserveToken;

    uint256 public totalLPShares;

    mapping(address => uint256) public lpBalance;

    uint256 public constant FEE_NUMERATOR = 997;
    uint256 public constant FEE_DENOMINATOR = 1000;

    error InvalidToken();
    error InvalidAmount();
    error InsufficientLiquidity();
    error InsufficientOutput();
    error InvalidShares();
    error TransferFailed();

    event LiquidityAdded(
        address indexed provider,
        uint256 ethAmount,
        uint256 tokenAmount,
        uint256 lpShares
    );

    event LiquidityRemoved(
        address indexed provider,
        uint256 ethAmount,
        uint256 tokenAmount,
        uint256 lpShares
    );

    event Swap(
        address indexed trader,
        bool ethToToken,
        uint256 amountIn,
        uint256 amountOut
    );

    constructor(address _token) {
        if (_token == address(0)) {
            revert InvalidToken();
        }

        token = IERC20(_token);
    }

    function addLiquidity(
        uint256 tokenAmount
    )
        external
        payable
        nonReentrant
        returns (uint256 lpShares)
    {
        uint256 ethAmount = msg.value;

        if (ethAmount == 0 || tokenAmount == 0) {
            revert InvalidAmount();
        }

        token.safeTransferFrom(
            msg.sender,
            address(this),
            tokenAmount
        );

        if (totalLPShares == 0) {
            lpShares = Math.sqrt(
                ethAmount * tokenAmount
            );
        } else {
            uint256 ethShare =
                (ethAmount * totalLPShares) /
                reserveETH;

            uint256 tokenShare =
                (tokenAmount * totalLPShares) /
                reserveToken;

            lpShares = Math.min(
                ethShare,
                tokenShare
            );
        }

        if (lpShares == 0) {
            revert InvalidShares();
        }

        reserveETH += ethAmount;
        reserveToken += tokenAmount;

        totalLPShares += lpShares;
        lpBalance[msg.sender] += lpShares;

        emit LiquidityAdded(
            msg.sender,
            ethAmount,
            tokenAmount,
            lpShares
        );
    }

    function removeLiquidity(
        uint256 lpShares
    )
        external
        nonReentrant
        returns (
            uint256 ethAmount,
            uint256 tokenAmount
        )
    {
        if (
            lpShares == 0 ||
            lpShares > lpBalance[msg.sender]
        ) {
            revert InvalidShares();
        }

        ethAmount =
            (lpShares * reserveETH) /
            totalLPShares;

        tokenAmount =
            (lpShares * reserveToken) /
            totalLPShares;

        if (
            ethAmount == 0 ||
            tokenAmount == 0
        ) {
            revert InsufficientLiquidity();
        }

        lpBalance[msg.sender] -= lpShares;
        totalLPShares -= lpShares;

        reserveETH -= ethAmount;
        reserveToken -= tokenAmount;

        token.safeTransfer(
            msg.sender,
            tokenAmount
        );

        (bool success, ) =
            payable(msg.sender).call{
                value: ethAmount
            }("");

        if (!success) {
            revert TransferFailed();
        }

        emit LiquidityRemoved(
            msg.sender,
            ethAmount,
            tokenAmount,
            lpShares
        );
    }

    function swapETHForToken()
        external
        payable
        nonReentrant
        returns (uint256 amountOut)
    {
        uint256 amountIn = msg.value;

        if (amountIn == 0) {
            revert InvalidAmount();
        }

        if (
            reserveETH == 0 ||
            reserveToken == 0
        ) {
            revert InsufficientLiquidity();
        }

        amountOut = getAmountOut(
            amountIn,
            reserveETH,
            reserveToken
        );

        if (
            amountOut == 0 ||
            amountOut >= reserveToken
        ) {
            revert InsufficientOutput();
        }

        reserveETH += amountIn;
        reserveToken -= amountOut;

        token.safeTransfer(
            msg.sender,
            amountOut
        );

        emit Swap(
            msg.sender,
            true,
            amountIn,
            amountOut
        );
    }

    function swapTokenForETH(
        uint256 tokenAmount
    )
        external
        nonReentrant
        returns (uint256 amountOut)
    {
        if (tokenAmount == 0) {
            revert InvalidAmount();
        }

        if (
            reserveETH == 0 ||
            reserveToken == 0
        ) {
            revert InsufficientLiquidity();
        }

        token.safeTransferFrom(
            msg.sender,
            address(this),
            tokenAmount
        );

        amountOut = getAmountOut(
            tokenAmount,
            reserveToken,
            reserveETH
        );

        if (
            amountOut == 0 ||
            amountOut >= reserveETH
        ) {
            revert InsufficientOutput();
        }

        reserveToken += tokenAmount;
        reserveETH -= amountOut;

        (bool success, ) =
            payable(msg.sender).call{
                value: amountOut
            }("");

        if (!success) {
            revert TransferFailed();
        }

        emit Swap(
            msg.sender,
            false,
            tokenAmount,
            amountOut
        );
    }

    function getAmountOut(
        uint256 amountIn,
        uint256 reserveIn,
        uint256 reserveOut
    )
        public
        pure
        returns (uint256)
    {
        if (
            amountIn == 0 ||
            reserveIn == 0 ||
            reserveOut == 0
        ) {
            return 0;
        }

        uint256 amountInWithFee =
            amountIn * FEE_NUMERATOR;

        uint256 numerator =
            amountInWithFee * reserveOut;

        uint256 denominator =
            (reserveIn * FEE_DENOMINATOR) +
            amountInWithFee;

        return numerator / denominator;
    }

    function getK()
        external
        view
        returns (uint256)
    {
        return reserveETH * reserveToken;
    }

    receive() external payable {
        revert("Use AMM functions");
    }
}