// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface ICampaignToken {
    function mint(
        address to,
        uint256 amount
    ) external;
}

contract Crowdfunding {

    struct Campaign {
        address creator;
        uint256 goal;
        uint256 deadline;
        uint256 amountRaised;
        bool withdrawn;
    }

    uint256 public campaignCount;

    // 1 ETH contribution = 1000 CFT
    uint256 public constant TOKENS_PER_ETH = 1000;

    ICampaignToken public immutable campaignToken;

    mapping(uint256 => Campaign)
        public campaigns;

    mapping(uint256 => mapping(address => uint256))
        public contributions;


    event CampaignCreated(
        uint256 indexed id,
        address indexed creator,
        uint256 goal,
        uint256 deadline
    );

    event ContributionMade(
        uint256 indexed id,
        address indexed contributor,
        uint256 amount,
        uint256 tokensReceived
    );

    event Withdrawn(
        uint256 indexed id,
        address indexed creator,
        uint256 amount
    );

    event Refunded(
        uint256 indexed id,
        address indexed contributor,
        uint256 amount
    );


    constructor(address _campaignToken) {

        require(
            _campaignToken != address(0),
            "Invalid token"
        );

        campaignToken =
            ICampaignToken(_campaignToken);
    }


    function createCampaign(
        uint256 _goal,
        uint256 _durationInSeconds
    )
        external
    {

        require(
            _goal > 0,
            "Goal must be greater than 0"
        );

        require(
            _durationInSeconds > 0,
            "Duration must be greater than 0"
        );

        campaignCount++;

        uint256 deadline =
            block.timestamp + _durationInSeconds;

        campaigns[campaignCount] = Campaign({
            creator: msg.sender,
            goal: _goal,
            deadline: deadline,
            amountRaised: 0,
            withdrawn: false
        });

        emit CampaignCreated(
            campaignCount,
            msg.sender,
            _goal,
            deadline
        );
    }


    function contribute(uint256 _id)
        external
        payable
    {

        Campaign storage c =
            campaigns[_id];

        require(
            c.creator != address(0),
            "Campaign does not exist"
        );

        require(
            msg.value > 0,
            "Must send ETH"
        );

        require(
            block.timestamp < c.deadline,
            "Campaign has ended"
        );


        c.amountRaised += msg.value;

        contributions[_id][msg.sender] +=
            msg.value;


        // IMPORTANT:
        // CFT uses 18 decimals.
        //
        // 0.001 ETH =
        // 1,000,000,000,000,000 wei
        //
        // × 1000 =
        // 1,000,000,000,000,000,000
        //
        // which is exactly 1 CFT.

        uint256 tokenAmount =
            msg.value * TOKENS_PER_ETH;


        campaignToken.mint(
            msg.sender,
            tokenAmount
        );


        emit ContributionMade(
            _id,
            msg.sender,
            msg.value,
            tokenAmount
        );
    }


    function withdrawFunds(uint256 _id)
        external
    {

        Campaign storage c =
            campaigns[_id];

        require(
            msg.sender == c.creator,
            "Only creator"
        );

        require(
            block.timestamp >= c.deadline,
            "Campaign active"
        );

        require(
            c.amountRaised >= c.goal,
            "Goal not reached"
        );

        require(
            !c.withdrawn,
            "Already withdrawn"
        );


        c.withdrawn = true;

        uint256 amount =
            c.amountRaised;


        (bool success,) =
            payable(c.creator).call{
                value: amount
            }("");

        require(
            success,
            "Transfer failed"
        );


        emit Withdrawn(
            _id,
            c.creator,
            amount
        );
    }


    function claimRefund(uint256 _id)
        external
    {

        Campaign storage c =
            campaigns[_id];

        require(
            block.timestamp >= c.deadline,
            "Campaign active"
        );

        require(
            c.amountRaised < c.goal,
            "Goal reached"
        );


        uint256 contributed =
            contributions[_id][msg.sender];

        require(
            contributed > 0,
            "No contribution"
        );


        contributions[_id][msg.sender] = 0;


        (bool success,) =
            payable(msg.sender).call{
                value: contributed
            }("");

        require(
            success,
            "Transfer failed"
        );


        emit Refunded(
            _id,
            msg.sender,
            contributed
        );
    }


    function getCampaign(uint256 _id)
        external
        view
        returns (
            address creator,
            uint256 goal,
            uint256 deadline,
            uint256 amountRaised,
            bool withdrawn
        )
    {

        Campaign memory c =
            campaigns[_id];

        return (
            c.creator,
            c.goal,
            c.deadline,
            c.amountRaised,
            c.withdrawn
        );
    }


    function getContribution(
        uint256 _id,
        address _contributor
    )
        external
        view
        returns (uint256)
    {

        return
            contributions[_id][_contributor];
    }
}